<script setup lang="ts"></script>

<template>
    <button class="bg-green-500 disabled:bg-gray-300 mx-2 rounded p-2 text-white">
        <slot></slot>
    </button>
</template>