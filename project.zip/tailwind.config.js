module.exports = {
  content: ["./index.html", "./src/**/*.{vue,ts}"],
};
